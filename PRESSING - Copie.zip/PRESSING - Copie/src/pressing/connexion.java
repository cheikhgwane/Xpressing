/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pressing;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
/**
 *
 * @author Administrateur
 */
public class connexion {
    Connection con;
    public connexion(){
        try{ 
        Class.forName("com.mysql.jbdc.Driver");
        }
        catch(ClassNotFoundException e){
        System.err.println(e);
        }
        try{
        con=DriverManager.getConnection("jbdc:mysql://localhost:3306/pressing/", "root","");
        }catch(SQLException e){System.err.println(e);}
    }
    Connection ObtenirConnexion(){return con;}

    
}
