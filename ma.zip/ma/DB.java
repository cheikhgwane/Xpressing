import org.sql2o.*;

public class DB
{
	public static Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:80/sparkdb_1","root",null);
}