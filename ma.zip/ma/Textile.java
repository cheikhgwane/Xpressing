public class Textile  {
	private int idTextile;
	private String nom;
	private String couleur;
	private int id_commande;
	public Textile(){}
	public Textile(int idTextile,String nom,String couleur,int id_commande){
		this.idTextile=idTextile;
		this.couleur=couleur;
		this.nom=nom;
        this.id_commande=id_commande;
	}public int getId_commande(){
        return this.id_commande;
    }
    public void setId_commande(int id_commande){
        this.id_commande=id_commande;
     public int getIdTextile(){
        return this.idTextile;
    }
    public void setIdTextile(int idTextile){
        this.idTextile=idTextile;
    }
    public String getCouleur(){
    	return this.couleur;
    }
    public void setCouleur(String couleur){
    	this.couleur=couleur;
    }
    public String getNom(){
    	return this.nom;
    }
    public void setNom(String nom){
    	this.nom=nom;
    }

}