public class Client extend Personne {
	
	private boolean etreNotifier;
	private int id;
	

	public Client(){}
	public Client(boolean etreNotifier,int id,String nom,String prenom,String tel,String adresse,String email){
		super( nom, prenom,tel,adresse,email);
        this.nom=nom;
        this.prenom=prenom;
        this.tel=tel;
        this.adresse=adresse;
        this.email=email;
		this.id=id;
		this.etreNotifier=etreNotifier;
	}public int getId(){
    	return this.id;
    }
    public void setId(int id){
    	this.id=id;
    }
    public boolean getEtreNotifier(){
    	return this.etreNotifier;
    }
    public void setEtreNotifier(boolean etreNotifier){
    	this.etreNotifier=etreNotifier;
    }
   
}