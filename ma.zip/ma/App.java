import java.util.HashMap;
import java.util.Map;
// import org.sql2o.*;
import java.sql.* ;
// import java.sql.DriverManager;
import spark.ModelAndView;
import java.util.ArrayList;

// import spark.template.velocity.VelocityTemplateEngine;
import spark.template.velocity.VelocityTemplateEngine;



import static spark.Spark.*;


public class App
 {


      public static String me = "";
      public static ArrayList<String> Users = new ArrayList<String>();
      public static String alls = "";

	  public static void main(String[] args)
	     {
 
         
	     staticFileLocation("/public");

         SqlQuery q = new SqlQuery();
         
         try {
            
            me = q.userPword("Shadow");
            
            Users = q.allUsers();

        } catch (Exception ex) {
            System.out.println(ex);
        }
 

	     get("/", (request, response) -> 

	       {
                

                Map map = new HashMap();
          
                // map.put("allProducts", Users);

                 map.put("base", "templates/css.vtl");
               //  map.put("log", "<img src='img/logo2.png' />");

                 
	        	return new ModelAndView(map , "templates/home.vtl");
	       }
	       ,new VelocityTemplateEngine());
    
        }
 
 }