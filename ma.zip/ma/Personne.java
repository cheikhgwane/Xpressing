public class Personne {
	private String nom;
	private String prenom;
	private String tel;
	private String adresse;
	private String email;

	public Personne(){}
	public Personne(String nom,String prenom,String tel,String adresse,String email){
        
		this.nom=nom;
		this.prenom=prenom;
		this.email=email;
		this.adresse=adresse;
		this.tel=tel;
	}
    public String getNom(){
    	return this.nom;}
    public void setNom(String nom){
    	this.nom=nom;
    }
    public String getPrenom(){
    	return this.prenom;
    }
    public void setPrenom(String prenom){
    	this.prenom=prenom;
    }
    public String getEmail(){
    	return this.email;
    }
    public void setEmail(String email){
    	this.email=email;
    }
    public String getAdresse(){
    	return this.adresse;
    }
    public void setAdresse(String adresse){
    	this.adresse=adresse;
    }
    
    public String getTel(){
    	return this.tel;
    }
    public void setTel(String tel){
    	this.tel=tel;
    }
}