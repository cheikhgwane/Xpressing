
public class Gerant extend Personne {
	
	private String password;
  private String matricule;
	private int idGerant;
	

	public Gerant(){}
	public Gerant(String password,int idGerant,String nom,String prenom,String tel,String adresse,String email,String matricule){
		super( nom, prenom,tel,adresse,email);
        this.nom=nom;
        this.prenom=prenom;
        this.tel=tel;
        this.adresse=adresse;
        this.email=email;
        this.password=password;
        this.matricule=matricule;
		this.idGerant=idGerant;
		this.password=password;
	}
  public int getMatricule(){
      return this.matricule;
    }
    public void setMatricule(String matricule){
      this.matricule=matricule;
    }
  public int getIdGerant(){
    	return this.idGerant;
    }
    public void setIdGerant(int idGerant){
    	this.idGerant=idGerant;
    }
    public String getPassword(){
    	return this.password;
    }
    public void setPassword(String password){
    	this.password=password;
    }
    public ArrayList<Textile> affichelisteTextile(int id_pressing , int idEmploye,int idDepot){
            ArrayList<Textile> list = new ArrayList<Textile>();
            String requete="select *from depots where id_pressing ="+id_pressing+"and idEmploye="+idEmploye+"and idDepot="+idDepot+"";
            result=St.executeQuery(requete);
           list = listeTextile.removeAllItems();
            while(result.next()){
                  listeTextile.addItem(result.getString("nom"));}
        return list;
    }
    public int nbreDepots(int id_pressing ){
           int count=0;
            ArrayList<Commande> list = new ArrayList<Commande>();
            String requete="select count(*) from depots where id_pressing ="+id_pressing+"";
            result=St.executeQuery(requete);
           list = listeCommandes.removeAllItems();
            while(result.next()){
                  listeCommandes.addItem(result.getString("nom"));}
        return count;
    }
      public int nbreDepotsParCli(int id_pressing , int id_client){
           int count=0;
            ArrayList<Commande> list = new ArrayList<Commande>();
            String requete="select count(*) from depots where id_pressing ="+id_pressing+"and id_client="+id_client+"";
            result=St.executeQuery(requete);
           list = listeCommandes.removeAllItems();
            while(result.next()){
                  listeCommandes.addItem(result.getString("nom"));}
        return count;
    }
 public int nbreDepotsParEmp(int id_pressing , int idEmploye){
           int count=0;
            ArrayList<Commande> list = new ArrayList<Commande>();
            String requete="select count(*) from depots where id_pressing ="+id_pressing+"and idEmploye="+idEmploye+"";
            result=St.executeQuery(requete);
           list = listeCommandes.removeAllItems();
            while(result.next()){
                  listeCommandes.addItem(result.getString("nom"));}
        return count;
    }
     public ArrayList<Commande> affichelisteDepots(int id_pressing , int idEmploye){
            ArrayList<Commande> list = new ArrayList<Commande>();
            String requete="select *from depots where id_pressing ="+id_pressing+"and idEmploye="+idEmploye+"";
            result=St.executeQuery(requete);
           list = listeCommandes.removeAllItems();
            while(result.next()){
                  listeCommandes.addItem(result.getString("nom"));}
        return list;
    }

    public ArrayList<Clients> affichelisteClients(int id_pressing) throws Exception{
          ArrayList<Clients> list = new ArrayList<Clients>();
          Statement stm = seConnecter();
          String requete="select * from clients where id_pressing ="+id_pressing+"";
          ResultSet result = execution(requete , stm);
            while(result.next()){
                  listeClients.addItem(result.getString("nom"));
            }
        
        return list;
    }
    public ArrayList<Employe> affichelisteEmploye( int id_pressing){
         
          ArrayList<Employe> list = new ArrayList<Employe>();
          Employe emp = new Employe();
          Statement stm = seConnecter();
          String requete="select  * from employes where id_pressing ="+id_pressing+"";
          ResultSet result = execution(requete, stm);
          //listeEmployes.removeAllItems();
          while(result.next()){
                  emp.setId(result.getInt("id"));
                  emp.setmatricule(result.getString("matricule"));
                  emp.setNom(result.getString("nom"));
                  emp.setPrenom(result.getString("prenom"));
                  list.add(emp);
            }
            result.close();
            stm.close();
        return list;
    }
    public static void ajoutEmploye(){
          try {
               
           String sqlajout="insert into employes values('"nom+"','"+prenom+"','"+id_pressing+"','"+pword+"')";
           cnx=DriverManager.getConnection("jdbc:mysql://localhost/xPressing","root","");
           St=cnx.createStatement();
           St.executeUpdate(sqlajout);
           AfficheEmploye();  
               
           
        } catch (Exception e) {
             System.out.println("Erreur lors de l'ajout"+e.getMessage());
        }
    }
}
