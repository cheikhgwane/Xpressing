public class Employe extend Personne {
	
	private String password;
	private int id;
    private String matricule;

	

	public Employe(){}
	public Employe(String password,int id,String matricule){
		super(nom,prenom,tel,adresse,email);
        this.nom=nom;
        this.prenom=prenom;
        this.tel=tel;
        this.adresse=adresse;
        this.email=email;
		this.id=id;
		this.password=password;
	}public int getId(){
    	return this.id;
    }
    public void setId(int id){
    	this.id=id;
    }
    public String getPassword(){
    	return this.password;
    }
    public void setPassword(String password){
    	this.password=password;
    }
    public String getMatricule(){
        return this.matricule;
    }
    public void setMatricule(String matricule){
        this.matricule=matricule;
    }
   
}