public class Commande{
	private int idPressing;
    private int numeroClient;
	private int numeroCommande;
    private int idTextile;
	private Date date;
	

	public Commande(){}
	public Commande(int idPressing,int numeroClient, int numeroCommande,int idTextile,Date date){
		this.numeroClient=numeroClient;
        this.numeroCommande= numeroCommande; 
        this.idTextile=idTextile;
		this.date=date;
		this.idPressing=idPressing;
	}
    public Date getDate(){
    	return this.date;
    }
    public void setDate(Date date){
    	this.date=date;
    }
    public int getIdPressing(){
    	return this.idPressing;
    }
    public void setIdPressing(int idPressing){
    	this.idPressing=idPressing;
    }
    public int getIdTextile(){
        return this.idTextile;
    }
    public void setIdTextile(int idTextile){
        this.idTextile=idTextile;
    } public int getNumeroClient(){
        return this.numeroClient;
    }
    public void setNumeroCommande(int numeroCommande){
        this.numeroCommande=numeroCommande;
    } public int getNumeroCommande(){
        return this.numeroCommande;
    }
    public void setNumeroClient(int numeroClient){
        this.numeroClient=numeroClient;
    }
}