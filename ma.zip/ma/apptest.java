// import org.sql2o.*;
// import java.sql.DriverManager;
// // import junit.*;
// // import static junit.Assert.*;

// public class apptest {

  
//   public void setUp() {
//     DB.sql2o = new Sql2o("jdbc:mysql://localhost:80/sparkbd_1", "root", null);
//   }

 
//   public void tearDown() {
//     try(Connection con = DB.sql2o.open()) {
//       String sql = "DELETE FROM users *;";
//       con.createQuery(sql).executeUpdate();
//     }
//   }

// }