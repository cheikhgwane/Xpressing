public class Pressing  {
	private int id;
	private String nom;
	private String localisation;
	

	public Pressing(){}
	public Pressing(String nom,String localisation){
		
		this.localisation=localisation;
		this.nom=nom;
	}public String getLocalisation(){
    	return this.localisation;
    }
    public void setLocalisation(String localisation){
    	this.localisation=localisation;
    }
    public String getNom(){
    	return this.nom;
    }
    public void setNom(String nom){
    	this.nom=nom;
    }
   
}